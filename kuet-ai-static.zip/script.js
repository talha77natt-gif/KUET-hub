// ── CONFIG ──────────────────────────────────────────────────────────────────
// Paste your Groq API key here (get one free at https://console.groq.com)
const GROQ_API_KEY = "YOUR_GROQ_API_KEY_HERE";

const GROQ_MODEL = "llama-3.3-70b-versatile";

const SYSTEM_PROMPT = `You are KUET AI Student Helper.

Rules:
- Answer shortly and clearly.
- Focus on KUET, admission, departments, routines, halls, academics.
- Reply in Bangla if user speaks Bangla.
- If unsure, say "I am not fully sure".`;

// ── STATE ────────────────────────────────────────────────────────────────────
let messages = [];
let isStreaming = false;

// ── NAVIGATION ───────────────────────────────────────────────────────────────
function showChat() {
  document.getElementById("landing").classList.add("hidden");
  document.getElementById("chat-page").classList.remove("hidden");
}

function showLanding() {
  document.getElementById("chat-page").classList.add("hidden");
  document.getElementById("landing").classList.remove("hidden");
}

function newChat() {
  messages = [];
  const container = document.getElementById("chat-messages");
  container.innerHTML = `
    <div class="welcome-screen" id="welcome-screen">
      <div class="welcome-icon">🤖</div>
      <h2>KUET AI Student Helper</h2>
      <p>Ask me anything about KUET — admission, departments, routines, halls, and more.</p>
      <div class="suggestions">
        <button class="chip" onclick="sendSuggestion('What are the departments in KUET?')">What are the departments in KUET?</button>
        <button class="chip" onclick="sendSuggestion('KUET admission process কেমন?')">KUET admission process কেমন?</button>
        <button class="chip" onclick="sendSuggestion('Tell me about KUET halls')">Tell me about KUET halls</button>
        <button class="chip" onclick="sendSuggestion('KUET CSE department details')">KUET CSE department details</button>
      </div>
    </div>`;
}

// ── INPUT HELPERS ─────────────────────────────────────────────────────────────
function handleKey(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

function autoResize(el) {
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 150) + "px";
}

function sendSuggestion(text) {
  document.getElementById("user-input").value = text;
  sendMessage();
}

// ── CHAT ──────────────────────────────────────────────────────────────────────
async function sendMessage() {
  if (isStreaming) return;

  const input = document.getElementById("user-input");
  const text = input.value.trim();
  if (!text) return;

  // Check API key
  if (!GROQ_API_KEY || GROQ_API_KEY === "YOUR_GROQ_API_KEY_HERE") {
    alert("Please open script.js and paste your Groq API key where it says YOUR_GROQ_API_KEY_HERE.\n\nGet a free key at https://console.groq.com");
    return;
  }

  // Hide welcome screen
  const welcome = document.getElementById("welcome-screen");
  if (welcome) welcome.remove();

  // Add user message
  messages.push({ role: "user", content: text });
  appendMessage("user", text);
  input.value = "";
  input.style.height = "auto";

  // Add to sidebar history
  addToHistory(text);

  // Disable send
  isStreaming = true;
  document.getElementById("send-btn").disabled = true;

  // Show typing indicator
  const typingId = "typing-" + Date.now();
  appendTyping(typingId);

  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        stream: true,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...messages,
        ],
        max_tokens: 1024,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      removeTyping(typingId);
      appendMessage("ai", "⚠️ Error: " + (response.status === 401 ? "Invalid API key. Check your GROQ_API_KEY in script.js." : "Something went wrong. Please try again."));
      console.error("Groq error:", response.status, err);
      return;
    }

    // Remove typing, add AI bubble
    removeTyping(typingId);
    const aiId = "ai-" + Date.now();
    appendStreamBubble(aiId);

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let fullContent = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data: ")) continue;
        const raw = trimmed.slice(6).trim();
        if (!raw || raw === "[DONE]") continue;

        try {
          const json = JSON.parse(raw);
          const chunk = json.choices?.[0]?.delta?.content;
          if (chunk) {
            fullContent += chunk;
            updateStreamBubble(aiId, fullContent);
          }
        } catch { /* skip malformed */ }
      }
    }

    messages.push({ role: "assistant", content: fullContent });

  } catch (err) {
    removeTyping(typingId);
    appendMessage("ai", "⚠️ Network error. Please check your internet connection and try again.");
    console.error("Chat error:", err);
  } finally {
    isStreaming = false;
    document.getElementById("send-btn").disabled = false;
    document.getElementById("user-input").focus();
  }
}

// ── DOM HELPERS ───────────────────────────────────────────────────────────────
function appendMessage(role, text) {
  const container = document.getElementById("chat-messages");
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.innerHTML = `
    <div class="avatar">${role === "user" ? "👤" : "🤖"}</div>
    <div class="bubble">${escapeHtml(text)}</div>`;
  container.appendChild(div);
  scrollToBottom();
}

function appendTyping(id) {
  const container = document.getElementById("chat-messages");
  const div = document.createElement("div");
  div.className = "message ai typing";
  div.id = id;
  div.innerHTML = `
    <div class="avatar">🤖</div>
    <div class="bubble">
      <div class="typing-dots"><span></span><span></span><span></span></div>
    </div>`;
  container.appendChild(div);
  scrollToBottom();
}

function removeTyping(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function appendStreamBubble(id) {
  const container = document.getElementById("chat-messages");
  const div = document.createElement("div");
  div.className = "message ai";
  div.id = id;
  div.innerHTML = `<div class="avatar">🤖</div><div class="bubble" id="bubble-${id}"></div>`;
  container.appendChild(div);
  scrollToBottom();
}

function updateStreamBubble(id, text) {
  const bubble = document.getElementById("bubble-" + id);
  if (bubble) {
    bubble.textContent = text;
    scrollToBottom();
  }
}

function scrollToBottom() {
  const container = document.getElementById("chat-messages");
  container.scrollTop = container.scrollHeight;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function addToHistory(text) {
  const history = document.getElementById("chat-history");
  const item = document.createElement("div");
  item.className = "history-item";
  item.textContent = text.length > 36 ? text.slice(0, 36) + "…" : text;
  history.prepend(item);
}
